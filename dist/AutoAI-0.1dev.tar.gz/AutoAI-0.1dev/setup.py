# -*- coding: utf-8 -*-
from distutils.core import setup

setup(name="AutoAI",
      version ='0.1dev',
      packages=['AutoAI',],
      license='GNU GPLv3',
      long_description=open('README.md').read())